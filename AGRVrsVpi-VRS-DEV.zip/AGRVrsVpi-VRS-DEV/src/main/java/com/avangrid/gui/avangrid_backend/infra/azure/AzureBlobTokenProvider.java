package com.avangrid.gui.avangrid_backend.infra.azure;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.Base64;
import java.util.concurrent.atomic.AtomicReference;

@Component
@Slf4j
public class AzureBlobTokenProvider {

    private static final String TOKEN_URL_TEMPLATE =
            "https://login.microsoftonline.com/%s/oauth2/v2.0/token";

    private final ObjectMapper objectMapper;
    private final String clientId;
    private final String clientSecret;
    private final String tenantId;
    private final String proxyHost;
    private final int proxyPort;
    private final String proxyUsername;
    private final String proxyPassword;

    private final AtomicReference<String> cachedToken;
    private final AtomicReference<Instant> tokenExpiry;

public AzureBlobTokenProvider(
        @Value("${azure.blob.client-id}") String clientId,
        @Value("${azure.blob.client-secret}") String clientSecret,
        @Value("${azure.blob.tenant-id}") String tenantId,
        @Value("${azure.proxy.host}") String proxyHost,
        @Value("${azure.proxy.port}") int proxyPort,
        @Value("${azure.proxy.username}") String proxyUsername,
        @Value("${azure.proxy.password}") String proxyPassword,
        ObjectMapper objectMapper) {
    this.clientId = clientId;
    this.clientSecret = clientSecret;
    this.tenantId = tenantId;
    this.proxyHost = proxyHost;
    this.proxyPort = proxyPort;
    this.proxyUsername = proxyUsername;
    this.proxyPassword = proxyPassword;
    this.objectMapper = objectMapper;
    // Initialize here — not at field level
    this.cachedToken = new AtomicReference<>();
    this.tokenExpiry = new AtomicReference<>();
    log.info("=== BlobTokenProvider using clientId: {} ===", clientId);
}
    public String getToken() {
        String token = cachedToken.get();
        Instant expiry = tokenExpiry.get();

        if (token != null &&
                expiry != null &&
                Instant.now().isBefore(expiry.minusSeconds(300))) {
            log.debug("Reusing cached blob token");
            return token;
        }

        log.info("Fetching new blob token for clientId: {}", clientId);
        try {
            Proxy proxy = new Proxy(
                    Proxy.Type.HTTP,
                    new InetSocketAddress(proxyHost, proxyPort)
            );

            URL url = new URL(String.format(TOKEN_URL_TEMPLATE, tenantId));
            HttpURLConnection conn =
                    (HttpURLConnection) url.openConnection(proxy);
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
            conn.setConnectTimeout(10000);
            conn.setReadTimeout(10000);

            // SonarQube fix — credentials from injected fields, not hardcoded
            String credentials = proxyUsername + ":" + proxyPassword;
            String encoded = Base64.getEncoder()
                    .encodeToString(
                            credentials.getBytes(StandardCharsets.UTF_8));
            conn.setRequestProperty("Proxy-Authorization", "Basic " + encoded);
            conn.setRequestProperty("Content-Type",
                    "application/x-www-form-urlencoded");

            String body = "grant_type=client_credentials"
                    + "&client_id=" + clientId
                    + "&client_secret=" + java.net.URLEncoder.encode(
                            clientSecret, StandardCharsets.UTF_8)
                    + "&scope=https://storage.azure.com/.default";

            try (OutputStream os = conn.getOutputStream()) {
                os.write(body.getBytes(StandardCharsets.UTF_8));
            }

            byte[] responseBytes = conn.getInputStream().readAllBytes();
            JsonNode json = objectMapper.readTree(responseBytes);

            String newToken = json.get("access_token").asText();
            long expiresIn = json.get("expires_in").asLong();
            Instant newExpiry = Instant.now().plusSeconds(expiresIn);

            cachedToken.set(newToken);
            tokenExpiry.set(newExpiry);

            log.info("Blob token fetched, expires in {}s", expiresIn);
            return newToken;

        } catch (Exception e) {
            log.error("Failed to fetch blob token: {}", e.getMessage());
            throw new RuntimeException("Failed to fetch Azure blob token", e);
        }
    }
}
