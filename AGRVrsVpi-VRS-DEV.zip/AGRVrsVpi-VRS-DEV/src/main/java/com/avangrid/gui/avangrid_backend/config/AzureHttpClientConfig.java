package com.avangrid.gui.avangrid_backend.config;

import com.azure.core.http.HttpClient;
import com.azure.core.http.netty.NettyAsyncHttpClientBuilder;
import io.netty.resolver.ResolvedAddressTypes;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.time.Duration;

@Configuration
public class AzureHttpClientConfig {

    @Bean
    public HttpClient azureNettyHttpClient() {
        reactor.netty.http.client.HttpClient reactorClient =
                reactor.netty.http.client.HttpClient.create()
                        .resolver(spec ->
                                spec.resolvedAddressTypes(ResolvedAddressTypes.IPV4_ONLY)
                        )
                        .responseTimeout(Duration.ofSeconds(30));

        return new NettyAsyncHttpClientBuilder(reactorClient).build();
    }
}
